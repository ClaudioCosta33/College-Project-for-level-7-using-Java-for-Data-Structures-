package LibraryProject;


public class Main {

    public static void main(String[] argc)
    {
        Menu s =new Menu();//start the System with MenuClass
        s.begin();
    }
}
